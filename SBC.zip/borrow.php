<?php



$conn = mysqli_connect("localhost", "root", "", "student_book_exchange");

if($conn->connect_errno > 0){
    die("Unable to connect: ". $conn->connect_error);
}


$query = " SELECT name,email,title,writter_name,isbn,status,price,date,image
           FROM student,book,book_donate";



$result = $conn->query($query);

if ($result->num_rows > 0) 
{
    // output data of each row

    while($row = $result->fetch_assoc())
    {
        echo "name: " . $row["name"]. "<br>
           - email: " . $row["email"]. "<br>
           - title: " . $row["title"]. "<br>
           - writter_name: " . $row["writter_name"]. "<br>
           - isbn: " . $row["isbn"]. "<br> 
           - status: " . $row["status"]. "<br>
           - price: " . $row["price"]. "<br>
           - date: " . $row["date"]. "<br>
           - image: " . $row["image"]. "<br>";
    }
}
else
{
    echo "0 results";
}


?>