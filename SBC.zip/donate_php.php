<?php
$target_dir = "C:\xampp\htdocs\Project\image";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);



    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "t";
    }

?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Book Exchange</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
	<h2>Donate</h2>
</div>
<form method="post" action="donate.php">

	<div class="input-group">
	<label>Name</label>
	<input type="text" name="name" >
	</div>
	<div class="input-group">
	<label>Date</label>
	<input type="text" name="date" >
	</div>
	<div class="input-group">
	<label>Price</label>
	<input type="text" name="price">
	</div>
	<div class="input-group">
	    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">


     <img src='<?php echo $target_file; ?>' width='100%' >
	</div>
	<div>
		<div class="input-group">
			<button type="submit" name="submit" class="btn">Subbmit</button>
		</div>
	</div>
	

</form>

</body>
</html>